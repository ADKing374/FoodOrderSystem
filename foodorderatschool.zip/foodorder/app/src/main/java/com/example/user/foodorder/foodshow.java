package com.example.user.foodorder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

/**
 * Created by USER on 2017/12/6.
 */
import android.app.Activity;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.ImageButton;

public class foodshow extends Activity {




    private View.OnClickListener btn1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            EditText editText = (EditText) findViewById(R.id.editText1);
            editText.setText("搜尋餐廳");

        }
    };

    private View.OnClickListener btn14_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodshow.this,activitymain.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btn22_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodshow.this,foodlist.class);
            startActivity(intent);

        }
    };

    /*private View.OnClickListener btn3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(mainorder.this,spaguetti.class);
            startActivity(intent);
        }
    };*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodshow);

        InitialComponent();

    }

    private void InitialComponent() {

        btncupcake=(ImageButton)findViewById(R.id.button1);
        btncupcake.setOnClickListener(btn1_click);
        btnhamburguer=(ImageButton)findViewById(R.id.button14);
        btnhamburguer.setOnClickListener(btn14_click);
        noodles=(ImageButton)findViewById(R.id.button22);
        noodles.setOnClickListener(btn22_click);

        /*btnspaguetti=(ImageButton)findViewById(R.id.button23);
        btnspaguetti.setOnClickListener(btn3_click);*/

    }


    ImageButton btncupcake;
    ImageButton btnhamburguer;
    ImageButton noodles;
//    ImageButton btnspaguetti;
}
