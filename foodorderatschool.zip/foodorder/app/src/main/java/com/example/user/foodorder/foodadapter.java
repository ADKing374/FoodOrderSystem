package com.example.user.foodorder;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by iii on 2017/12/6.
 */

public class foodadapter extends Activity {

    ListView lst;
    String[] foodname = {"Bread"};
    String[] desc= {"This is Bread"};
    String[] foodprice = {"$30"};
    Integer[] imgid={R.drawable.bread};

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adapter);

    }

    class CustomAdaptor extends BaseAdapter {

        @Override
        public int getCount() {
            return imgid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = getLayoutInflater().inflate(R.layout.foodlist,null);
            ImageView ivw = (ImageView) view.findViewById(R.id.imageview1);
            TextView tvw1 = (TextView)view.findViewById(R.id.tvproductname);
            TextView tvw2 = (TextView)view.findViewById(R.id.tvdescription);
            TextView tvw3 = (TextView)view.findViewById(R.id.tvprice);
            ivw.setImageResource(imgid[position]);
            tvw1.setText(foodname[position]);
            tvw2.setText(desc[position]);
            tvw3.setText(foodprice[position]);


            return view;
        }
    }
}