package com.example.user.foodorder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by iii on 2017/12/6.
 */

/**
 * Created by USER on 2017/12/4.
 */

public class foodlist extends Activity implements ListView.OnItemClickListener{

    ListView lst;
    String[] foodname = {"Bread","Szushi","Bento","coffee","doughnut","fastfood","noodles","pizza","sandwitch"};
    String[] desc= {"This is Bread","This is Sushi","This is Bento","This is coffee","This is doughnut","This is fastfood","This is noodles","This is pizza","This is sandwitch"};
    String[] foodprice = {"$30","$35","$40","$45","$50","$55","$100","$25","$69"};
    Integer[] imgid={R.drawable.bread,R.drawable.sushi,R.drawable.bento,R.drawable.coffee,R.drawable.doughnut,R.drawable.fastfood,R.drawable.noodles,R.drawable.pizza,R.drawable.sandwich};

    private View.OnClickListener toactivitymain_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodlist.this,activitymain.class);
            startActivity(intent);
        }
    };


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodlistlayout);

        lst=(ListView)findViewById(R.id.listview);


        CustomAdaptor customAdaptor = new CustomAdaptor();
        lst.setAdapter(customAdaptor);

        /*ImageButton plusbtn=(ImageButton)findViewById(R.id.plusimg);
        plusbtn.setOnClickListener(plus_click);

        ImageButton minusbtn=(ImageButton)findViewById(R.id.minusimg);
        minusbtn.setOnClickListener(this);*/
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(foodlist.this,foodshow.class);
        startActivity(intent);
        toorder();
        Toast message = Toast.makeText(foodlist.this, "完成", Toast.LENGTH_SHORT);
        message.show();
    }


    class CustomAdaptor extends BaseAdapter {

        @Override
        public int getCount() {
            return imgid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = getLayoutInflater().inflate(R.layout.foodlist,null);
            ImageView ivw = (ImageView) view.findViewById(R.id.imageview1);
            TextView tvw1 = (TextView)view.findViewById(R.id.tvproductname);
            TextView tvw2 = (TextView)view.findViewById(R.id.tvdescription);
            TextView tvw3 = (TextView)view.findViewById(R.id.tvprice);
            ivw.setImageResource(imgid[position]);
            tvw1.setText(foodname[position]);
            tvw2.setText(desc[position]);
            tvw3.setText(foodprice[position]);


            return view;
        }
    }

    private void toorder() {

        toactivitymain=(Button)findViewById(R.id.button1);
        toactivitymain.setOnClickListener(toactivitymain_click);


    }

    Button toactivitymain;

}

