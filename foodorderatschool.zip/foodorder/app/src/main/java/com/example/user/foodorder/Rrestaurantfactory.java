package com.example.user.foodorder;

/**
 * Created by USER on 2017/12/6.
 */

import java.util.ArrayList;
/**
 * Created by iii on 2017/12/5.
 */

public class Rrestaurantfactory {


    private ArrayList<Rrestaurant> list=new ArrayList<Rrestaurant>();
    private int position=0;

    public Rrestaurantfactory(){
        LoadData();
    }

    private void LoadData(){
        list.add(new Rrestaurant("A001","Hamburger","60",R.drawable.bento));
        list.add(new Rrestaurant("A002","Noodles","70",R.drawable.coffee));
        list.add(new Rrestaurant("A003","Steak","99",R.drawable.bread));
    }
    public void MoveToFirst(){
        position=0;
    }
    public void MoveToPrevious(){
        position--;
        if(position<0)
            position=0;
    }
    public void MoveToNext(){
        position++;
        if(position>=list.size())
            MoveToLast();
    }
    public void MoveToLast(){
        position=list.size()-1;
    }
    public void MoveTo(int to){
        position=to;
    }
    public Rrestaurant GetCurrent(){
        return list.get(position);
    }
    public Rrestaurant[] GetAll(){
        return list.toArray(new Rrestaurant[list.size()]);
    }

}

