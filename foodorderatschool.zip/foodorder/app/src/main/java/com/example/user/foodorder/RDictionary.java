package com.example.user.foodorder;

/**
 * Created by USER on 2017/12/6.
 */
/**
 * Created by iii on 2017/12/5.
 */

public class RDictionary {
    public static final String BK_CUSTOMERS_LIST="BK_CUSTOMERS_LIST";
    public static final String BK_SELECTED_INDEX = "BK_SELECTED_INDEX";
    public static final int ACTID_ACTLIST = 123;

}