package com.example.user.foodorder;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.text.DecimalFormat;

public class activitymain extends Activity {


    Rrestaurantfactory Rrestaurantfactory = new Rrestaurantfactory();

    private View.OnClickListener button1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String[] customers=new String[Rrestaurantfactory.GetAll().length];
            int count=0;
            for(Rrestaurant c : Rrestaurantfactory.GetAll()){
                customers[count]=c.getName()+"\r\n"+
                        c.getPrice()+" / "+c.getId();
                count++;
            }

            Bundle bund = new Bundle();
            bund.putStringArray(RDictionary.BK_CUSTOMERS_LIST,customers);
            Intent intent =new Intent(activitymain.this,actlist.class);
            intent.putExtras(bund);
            startActivityForResult(intent,RDictionary.ACTID_ACTLIST);


        }
    };

    private View.OnClickListener button2_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            InitialComponent();
            double a=Double.parseDouble(editText3.getText().toString());
            double b=Double.parseDouble(editText4.getText().toString());
            double r= a*b;

            DecimalFormat format = new DecimalFormat("0.00");

            textview6.setText(format.format(r));

            Toast message = Toast.makeText(activitymain.this, "計算完成", Toast.LENGTH_SHORT);
            message.show();

        }
    };

    private DialogInterface.OnClickListener btnOK_click = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            Intent intent = new Intent(activitymain.this,orderlist.class);
            startActivity(intent);
        }




    };

    private DialogInterface.OnClickListener btnNO_click = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {

        }




    };

    private View.OnClickListener button3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            AlertDialog.Builder builder = new AlertDialog.Builder(activitymain.this);
            builder.setIcon(R.drawable.dialog);
            builder.setTitle("訂購訊息");
            builder.setMessage("是否已購買完成?");
            builder.setPositiveButton("是",btnOK_click);
            builder.setNegativeButton("否",btnNO_click);
            Dialog message= builder.create();
            message.show();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitymain);
        InitialComponent();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==RDictionary.ACTID_ACTLIST){
            if(data==null||data.getExtras()==null)
                return;
            int index=data.getExtras().getInt(RDictionary.BK_SELECTED_INDEX);
            Rrestaurantfactory.MoveTo(index);
            DisplayCustomerInfo();
        }
    }


    private void DisplayCustomerInfo() {
        editText1.setText(Rrestaurantfactory.GetCurrent().getId());
        editText2.setText(Rrestaurantfactory.GetCurrent().getName());
        editText3.setText(Rrestaurantfactory.GetCurrent().getPrice());
        imageView1.setImageResource(Rrestaurantfactory.GetCurrent().getPic());

    }


    private void InitialComponent() {

        editText1=(EditText)findViewById(R.id.editText1);
        editText2=(EditText)findViewById(R.id.editText2);
        editText3=(EditText)findViewById(R.id.editText3);
        editText4=(EditText)findViewById(R.id.editText4);
        textview6=(TextView)findViewById(R.id.textView6);



        button1=(Button)findViewById(R.id.button1);
        button1.setOnClickListener(button1_click);
        button2=(Button)findViewById(R.id.button2);
        button2.setOnClickListener(button2_click);
        button3=(Button)findViewById(R.id.button3);
        button3.setOnClickListener(button3_click);

        imageView1=(ImageView)findViewById(R.id.imageView1);


    }



    EditText editText1;
    EditText editText2;
    EditText editText3;
    EditText editText4;
    TextView textview6;
    Button button1;
    Button button2;
    Button button3;
    ImageView imageView1;



}
