package com.example.user.foodorder;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by iii on 2017/12/6.
 */

/**
 * Created by USER on 2017/12/4.
 */

public class foodlist extends Activity implements ListView.OnItemClickListener{

    ListView lst;
    String[] foodname = {"丹丹漢堡","花小豬韓式料理","廣澤鮓日本料理","閨蜜。創義廚房","廣寒樓韓食館","元町日式食堂","前金肉燥飯","港都魚肉羮","1920咖哩專門店"};
    String[] desc= {"專賣漢堡、薯條、可樂等快速食品。","販售泡菜鍋,炸醬麵,烤五花肉","生魚片,蒸蛋,烤秋刀魚","義式餐點、披薩和牛排館","泡菜、醃蘿蔔、石鍋拌飯","豬排飯、炒烏龍麵、炸花枝蝦球","肉燥飯、四神湯、滷豆腐","土魠魚羹、土托魚羹米粉","初戀咖哩飯、冰火咖哩飯"};
    String[] foodprice = {"801高雄市前金區七賢二路224號","801高雄市前金區光明街3號","801高雄市前金區文武二街163號","801高雄市前金區中正四路211號","801高雄市前金區前金二街51號","801高雄市前金區前金一街15號","801高雄市前金區大同二路26號","801高雄市前金區自強二路124號","801高雄市前金區自強二路114號"};
    Integer[] imgid={R.drawable.store,R.drawable.store1,R.drawable.store2,R.drawable.store3,R.drawable.store4,R.drawable.store5,R.drawable.store6,R.drawable.store7,R.drawable.store8};

    private View.OnClickListener toactivitymain_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodlist.this,activitymain.class);
            startActivity(intent);
        }
    };


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodlistlayout);
        toorder();
        lst=(ListView)findViewById(R.id.listview);


        CustomAdaptor customAdaptor = new CustomAdaptor();
        lst.setAdapter(customAdaptor);

        /*ImageButton plusbtn=(ImageButton)findViewById(R.id.plusimg);
        plusbtn.setOnClickListener(plus_click);

        ImageButton minusbtn=(ImageButton)findViewById(R.id.minusimg);
        minusbtn.setOnClickListener(this);*/
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(foodlist.this,foodshow.class);
        startActivity(intent);

        Toast message = Toast.makeText(foodlist.this, "完成", Toast.LENGTH_SHORT);
        message.show();
    }


    class CustomAdaptor extends BaseAdapter {

        @Override
        public int getCount() {
            return imgid.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View view = getLayoutInflater().inflate(R.layout.foodlist,null);
            ImageView ivw = (ImageView) view.findViewById(R.id.imageview1);
            TextView tvw1 = (TextView)view.findViewById(R.id.tvproductname);
            TextView tvw2 = (TextView)view.findViewById(R.id.tvdescription);
            TextView tvw3 = (TextView)view.findViewById(R.id.tvprice);
            ivw.setImageResource(imgid[position]);
            tvw1.setText(foodname[position]);
            tvw2.setText(desc[position]);
            tvw3.setText(foodprice[position]);


            return view;
        }
    }

    private void toorder() {

        toactivitymain=(Button)findViewById(R.id.toactivitymain);
        toactivitymain.setOnClickListener(toactivitymain_click);


    }

    Button toactivitymain;

}

