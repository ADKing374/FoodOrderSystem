package com.example.user.foodorder;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;

/**
 * Created by USER on 2017/12/6.
 */
import android.app.Activity;
        import android.content.Intent;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.ImageButton;

public class foodshow extends Activity {


    DatePickerDialog.OnDateSetListener date_set=new DatePickerDialog.OnDateSetListener()
    {
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3)
        {
            editText1.setText(String.valueOf(arg1)+"/"+
                    String.valueOf(arg2+1)+"/"+
                    String.valueOf(arg3));
        }
    };


    private View.OnClickListener btn14_click = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View v) {
            Calendar today=Calendar.getInstance();

            EditText editText = (EditText) findViewById(R.id.editText1);
            editText.setText("歡迎光臨訂餐APP");

            DatePickerDialog message=new DatePickerDialog(
                    foodshow.this,
                    date_set,
                    today.get(Calendar.YEAR),
                    today.get(Calendar.MONTH),
                    today.get(Calendar.DATE)
            );
            message.show();


        }
    };
    private View.OnClickListener btn1_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodshow.this,activitymain.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btn21_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodshow.this,activitymain.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btn20_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(foodshow.this,foodlist.class);
            startActivity(intent);

        }
    };

    /*private View.OnClickListener btn3_click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(mainorder.this,spaguetti.class);
            startActivity(intent);
        }
    };*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodshow);

        InitialComponent();

    }

    private void InitialComponent() {

        editText1=(EditText)findViewById(R.id.editText1);
        btncupcake=(ImageButton)findViewById(R.id.button1);
        btncupcake.setOnClickListener(btn1_click);
        btndate=(ImageButton)findViewById(R.id.button14);
        btndate.setOnClickListener(btn14_click);
        btnhamburguer=(ImageButton)findViewById(R.id.button21);
        btnhamburguer.setOnClickListener(btn21_click);
        noodles=(ImageButton)findViewById(R.id.button20);
        noodles.setOnClickListener(btn20_click);

        /*btnspaguetti=(ImageButton)findViewById(R.id.button23);
        btnspaguetti.setOnClickListener(btn3_click);*/

    }

    EditText editText1;
    ImageButton btncupcake;
    ImageButton btndate;
    ImageButton btnhamburguer;
    ImageButton noodles;
//    ImageButton btnspaguetti;
}
