package com.example.user.foodorder;

/**
 * Created by USER on 2017/12/6.
 */

import java.util.ArrayList;
/**
 * Created by iii on 2017/12/5.
 */

public class Rrestaurantfactory {


    private ArrayList<Rrestaurant> list=new ArrayList<Rrestaurant>();
    private int position=0;

    public Rrestaurantfactory(){
        LoadData();
    }

    private void LoadData(){
        list.add(new Rrestaurant("A001","便當","60",R.drawable.bento));
        list.add(new Rrestaurant("A002","麵包","70",R.drawable.bread));
        list.add(new Rrestaurant("A003","咖啡","80",R.drawable.coffee));
        list.add(new Rrestaurant("A004","包子","12",R.drawable.dimsum));
        list.add(new Rrestaurant("A005","甜甜圈","20",R.drawable.doughnut));
        list.add(new Rrestaurant("A006","速食","99",R.drawable.fastfood));
        list.add(new Rrestaurant("A007","飲料","25",R.drawable.frappe));
        list.add(new Rrestaurant("A008","熱狗","30",R.drawable.hotdog));
        list.add(new Rrestaurant("A009","冰淇淋","45",R.drawable.icecream));
        list.add(new Rrestaurant("A0010","燒烤","20",R.drawable.kebab));
        list.add(new Rrestaurant("A0011","牛奶","38",R.drawable.milk));
        list.add(new Rrestaurant("A0012","麵條","40",R.drawable.noodles));
        list.add(new Rrestaurant("A0013","比薩","108",R.drawable.pizza));
        list.add(new Rrestaurant("A0014","三明治","55",R.drawable.sandwich));
        list.add(new Rrestaurant("A0015","牛肉湯","80",R.drawable.soup));
        list.add(new Rrestaurant("A0016","牛排","399",R.drawable.steak));
        list.add(new Rrestaurant("A0017","火鍋","499",R.drawable.stew));
        list.add(new Rrestaurant("A0018","壽司","50",R.drawable.sushi));
        list.add(new Rrestaurant("A0019","玉米餅","99",R.drawable.taco));

    }
    public void MoveToFirst(){
        position=0;
    }
    public void MoveToPrevious(){
        position--;
        if(position<0)
            position=0;
    }
    public void MoveToNext(){
        position++;
        if(position>=list.size())
            MoveToLast();
    }
    public void MoveToLast(){
        position=list.size()-1;
    }
    public void MoveTo(int to){
        position=to;
    }
    public Rrestaurant GetCurrent(){
        return list.get(position);
    }
    public Rrestaurant[] GetAll(){
        return list.toArray(new Rrestaurant[list.size()]);
    }

}

